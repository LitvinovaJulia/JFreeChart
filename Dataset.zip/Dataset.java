package com.company;

import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class Dataset {
    public static final String[] SECTIONS = {"Программирование", "ООП", "Физика", "Математический анализ"};
    public static final int[] EXPENSES = {138, 84, 140, 148};

    public static PieDataset createPieDataset(final int[] expenses) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (int i = 0; i < SECTIONS.length; i++)
            dataset.setValue(SECTIONS[i], new Integer(expenses[i]));
        return dataset;
    }
}
