package com.company;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import javax.swing.*;
import java.util.ArrayList;

public class JFreeChartLineChartExample extends JFrame {

    private static final long serialVersionUID =1L;

    public JFreeChartLineChartExample(String applicationTitle, String chartTitle, ArrayList<Integer> list) {
        super(applicationTitle);
        JFreeChart pieChart = ChartFactory.createXYLineChart(chartTitle, "Время", "прогресс", createDataset(list), PlotOrientation.VERTICAL, true, true, false);
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(1000, 270));
        setContentPane(chartPanel);
    }


    public XYDataset createDataset(ArrayList<Integer> listx) {
        XYSeries Функция = new XYSeries("Функция");
        for (int i = 0; i < listx.size(); i += 2) {
            Функция.add(listx.get(i), listx.get(i + 1));
        }
        final XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(Функция);
        return dataset;
    }

}
