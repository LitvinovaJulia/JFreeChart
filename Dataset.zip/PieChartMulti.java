package com.company;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.ui.ApplicationFrame;
import org.jfree.data.general.PieDataset;
import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;

public class PieChartMulti extends ApplicationFrame {
    private static final long serialVersionUID = 1L;

    PieDataset dataset;
    JFreeChart chart1, chart3;
    PieSectionLabelGenerator pslg;

    public PieChartMulti(String title) {
        super(title);
        JPanel panel = new JPanel(new GridLayout(2, 1));
        dataset = com.company.Dataset.createPieDataset(com.company.Dataset.EXPENSES);

        chart1 = ChartFactory.createPieChart("Количество учебных часов", dataset, false, false, false);
        PiePlot plot1 = (PiePlot)chart1.getPlot();
        pslg = new StandardPieSectionLabelGenerator("{0} = {1}", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance());
        plot1.setLabelGenerator(pslg);
        panel.add(new ChartPanel(chart1));

        chart3 = ChartFactory.createPieChart3D("Распределение учебных часов", dataset, false, false, false);
        PiePlot3D plot3 = (PiePlot3D)chart3.getPlot();
        plot3.setCircular(true);
        plot3.setForegroundAlpha(0.5f);
        pslg = new StandardPieSectionLabelGenerator("{0} = {2}", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance());
        plot3.setLabelGenerator(pslg);
        panel.add(new ChartPanel(chart3));

        panel.setPreferredSize(new Dimension(700, 700));
        setContentPane(panel);
    }
}
