package com.company;

import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RefineryUtilities;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Придумайте название для диаграммы");
        String name = input.nextLine();
        System.out.println("Введите значения X:Y для построения графика (не менее одного значения, для завершенния введте END)");
        ArrayList<Integer> list = new ArrayList<>();
        boolean check = false;

        final int x = 0;
        final int y = 1;

        do{
            String str = input.nextLine();
            Pattern o = Pattern.compile("[0-9]+:[0-9]+$");
            Matcher om = o.matcher(str);
            if (str.equalsIgnoreCase("end")) {
                check = true;
            } else if (!om.find()){
                System.out.println("Введите заново");
            } else {
                String[] mass = str.split(":");
                list.add(Integer.valueOf(mass[x]));
                list.add(Integer.valueOf(mass[y]));
            }
        } while (!check);

       JFreeChartLineChartExample chart0 = new JFreeChartLineChartExample(name, name, list);
        chart0.pack();
        chart0.setVisible(true);


        XYSeries series = new XYSeries("cos(a)");
        XYSeries series1 = new XYSeries("sin(a)");
        for (float i = 0; i < Math.PI; i += 0.1) {
            series.add(i, Math.cos(i));
            series1.add(i, Math.sin(i));
        }


        XYDataset xyDataset = new XYSeriesCollection(series);
        XYDataset xyDataset1 = new XYSeriesCollection(series1);

        JFreeChart chart = ChartFactory.createXYLineChart("y = cos(x)", "x", "y", xyDataset, PlotOrientation.VERTICAL, true, true, true);
        JFrame frame = new JFrame("MinimalStaticChart");
        frame.getContentPane().add(new ChartPanel(chart));
        frame.setSize(500, 800);
        frame.show();

        JFreeChart chart1 = ChartFactory.createXYLineChart("y = sin(x)", "x", "y", xyDataset1, PlotOrientation.VERTICAL, true, true, true);
        JFrame frame1 = new JFrame("MinimalStaticChart");
        frame1.getContentPane().add(new ChartPanel(chart));
        frame1.getContentPane().add(new ChartPanel(chart1));
        frame1.setSize(1200, 600);
        frame1.show();


        PieChartMulti demo = new PieChartMulti("Круговая диаграмма");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);

    }
}
